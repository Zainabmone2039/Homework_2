import socket

# Create TCP client socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(('localhost', 8000))

try:
    while True:
        # Receive message from server
        message = client_socket.recv(1024).decode()
        if not message:
            break

        print(message)

        if message.startswith("Please enter your account name and password"):
            # Send account name and password
            account_name = input("Account Name: ")
            password = input("Password: ")
            client_socket.send(f"{account_name} {password}".encode())
        elif message.startswith("Please choose an option"):
            # Send user's choice
            choice = input("Enter your choice (1-4): ")
            client_socket.send(choice.encode())
        elif message.startswith("Enter amount to deposit"):
            # Send deposit amount
            amount = input("Amount to deposit: ")
            client_socket.send(amount.encode())
        elif message.startswith("Enter amount to withdraw"):
            # Send withdrawal amount
            amount = input("Amount to withdraw: ")
            client_socket.send(amount.encode())
        elif message.startswith("Your final balance is"):
            # Print final balance and exit
            print(message)
            break
        else:
            # Print server's response
            print(message)
finally:
    client_socket.close()