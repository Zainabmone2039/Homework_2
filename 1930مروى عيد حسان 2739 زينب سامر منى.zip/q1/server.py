import socket
import threading

# Dictionary to store account details
accounts = {
    "u1": {"password": "p1", "balance": 1000.0},
    "u2": {"password": "p2", "balance": 2000.0},
    "u3": {"password": "p3", "balance": 3000.0}
}

# Create TCP server socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
server_socket.bind(('localhost', 8000))
server_socket.listen(5)

print("Bank ATM Server started. Waiting for client connections...")

def handle_client(conn, addr):
    print(f"New connection from {addr}")

    # Authenticate client
    authenticated = False
    while not authenticated:
        conn.send("Please enter your account name and password (separated by a space): ".encode())
        data = conn.recv(1024).decode().strip().split()
        if len(data) != 2:
            conn.send("Invalid input. Please try again.".encode())
            continue

        account_name, password = data
        if account_name in accounts and accounts[account_name]["password"] == password:
            authenticated = True
            conn.send("Authentication successful. Welcome to the Bank ATM!".encode())
        else:
            conn.send("Invalid account name or password. Please try again.".encode())

    # Handle banking operations
    while True:
        conn.send("Please choose an option (1. Check Balance, 2. Deposit, 3. Withdraw, 4. Quit): ".encode())
        option = conn.recv(1024).decode().strip()

        if option == "1":
            balance = accounts[account_name]["balance"]
            conn.send(f"Your current balance is: {balance:.2f}".encode())
        elif option == "2":
            conn.send("Enter amount to deposit: ".encode())
            amount = float(conn.recv(1024).decode().strip())
            accounts[account_name]["balance"] += amount
            conn.send(f"Deposit successful. Your new balance is: {accounts[account_name]['balance']:.2f}".encode())
        elif option == "3":
            conn.send("Enter amount to withdraw: ".encode())
            amount = float(conn.recv(1024).decode().strip())
            if amount > accounts[account_name]["balance"]:
                conn.send("Insufficient funds.".encode())
            else:
                accounts[account_name]["balance"] -= amount
                conn.send(f"Withdrawal successful. Your new balance is: {accounts[account_name]['balance']:.2f}".encode())
        elif option == "4":
            conn.send(f"Your final balance is: {accounts[account_name]['balance']:.2f}".encode())
            break
        else:
            conn.send("Invalid option. Please try again.".encode())

    conn.close()
    print(f"Connection with {addr} closed.")

while True:
    conn, addr = server_socket.accept()
    client_thread = threading.Thread(target=handle_client, args=(conn, addr))
    client_thread.start()